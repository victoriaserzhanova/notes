[todo]: # (Title: Be as meaningful as possible)
[todo]: # (Title: Try to use 60 or less chars)

[todo]: # (This is only a template!)
[todo]: # (remove unneeded bits)
[todo]: # (use github preview!)

## input.scss

[todo]: # (always test and report with scss syntax)
[todo]: # (use sass only when results differ from scss)

```scss
test {
  content: bar
}
```

## Actual results

[todo]: # (update version info!)

[libsass 3.X.y][1]
```css
test {
  content: bar; }
```

## Expected result

[todo]: # (update version info!)

ruby sass 3.X.y
```css
test {
  content: bar; }
```

[todo]: # (update version info!)
[todo]: # (example for node-sass!)

version info:
```cmd
$ node-sass --version
node-sass       3.X.y   (Wrapper)       [JavaScript]
libsass         3.X.y   (Sass Compiler) [C/C++]
```

[todo]: # (Go to http://libsass.ocbnet.ch/srcmap)
[todo]: # (Enter your SCSS code and hit compile)
[todo]: # (Click `bookmark` and replace the url)
[todo]: # (link is used in actual results above)

[1]: http://libsass.ocbnet.ch/srcmap/#dGVzdCB7CiAgY29udGVudDogYmFyOyB9Cg==
